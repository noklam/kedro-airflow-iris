"""New Kedro Project
"""

__version__ = "0.1"
